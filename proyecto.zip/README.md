# EduPlanEB 1.7.1

Revisión de 1.7: corrige errores que impedían compilar y prepara la construcción del APK.

## Cambios en esta versión
- Imports faltantes (`share_plus`, `pdf`, `printing`): la app no compilaba.
- `CreatePlanPage` se llamaba sin `planType` (error de compilación); nueva pantalla **Planes** para elegir tipo de plan.
- `ResourceCreatePage` usaba `sourceText` sin declararlo (error de compilación).
- `Supabase.initialize` usa `anonKey` (parámetro válido en supabase_flutter).
- Exportar Word (RTF): ahora conserva tildes, ñ y saltos de línea.
- "Usar mi horario" ya no rompe el desplegable de grado/asignatura con textos libres.
- `main.dart` duplicado en la raíz eliminado.
- SDK mínimo subido a Dart 3.7 (lo exige `syncfusion_flutter_pdf` 31.x).
- Función de Supabase: el prompt ahora pide las claves JSON que la app espera (antes la IA podía devolver claves que la app no mostraba).
- Permiso INTERNET añadido al manifiesto (sin él, la APK release no se conecta a Supabase).

## Obtener el APK (elige una vía)
**A) En la nube, sin instalar nada (GitHub):** sube esta carpeta a un repositorio nuevo → pestaña *Actions* → *Construir APK* → *Run workflow* → al terminar descarga `EduPlanEB-apk` (contiene `app-release.apk`).

**B) En tu computadora** (con Flutter estable instalado): `bash build_apk.sh` (Windows: `build_apk.bat`).
APK en `build/app/outputs/flutter-apk/app-release.apk`.

## Instalar en el celular
Pasa el APK al teléfono → ábrelo → permite "instalar apps de origen desconocido" si lo pide.

## Pendiente
- **No se pudo compilar ni probar aquí** (sin Flutter SDK): el código se revisó a mano. Si `flutter analyze` marca algo, pásame el mensaje.
- Recuperación de contraseña en móvil: falta configurar redirección/deep link en Supabase Auth y la pantalla para nueva contraseña.
- Clave de IA: definir `OPENAI_API_KEY` en los secretos de Supabase y desplegar la función `eduplaneb-generate-plan`; sin ella devuelve un borrador básico.
- Syncfusion: requiere licencia (la Community es gratuita para casos elegibles).
- Las tablas/bucket de Supabase (`profiles`, `plans`, `books`, `book-files`, etc.) deben existir con sus políticas RLS.
- La APK se firma con clave de depuración: sirve para instalar y probar, no para Google Play.
