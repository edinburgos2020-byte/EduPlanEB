@echo off
REM Uso en Windows (Flutter instalado y en PATH): doble clic o ejecutar build_apk.bat
if not exist android call flutter create --platforms=android --org com.eduplaneb --project-name eduplaneb .
call flutter pub get
powershell -NoProfile -Command "$m='android\app\src\main\AndroidManifest.xml'; $t=Get-Content $m -Raw; if($t -notmatch 'android.permission.INTERNET'){ $t=$t -replace '(<manifest[^>]*>)','$1`n    <uses-permission android:name=\"android.permission.INTERNET\"/>' }; $t=$t -replace 'android:label=\"[^\"]*\"','android:label=\"EduPlanEB\"'; Set-Content $m $t"
call flutter build apk --release
echo.
echo APK: build\app\outputs\flutter-apk\app-release.apk
pause
