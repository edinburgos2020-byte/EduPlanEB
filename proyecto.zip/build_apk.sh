#!/usr/bin/env bash
# Uso (Linux/macOS/WSL con Flutter instalado):  bash build_apk.sh
set -euo pipefail
[ -d android ] || flutter create --platforms=android --org com.eduplaneb --project-name eduplaneb .
bash tool/patch_android.sh
flutter pub get
flutter build apk --release
echo; echo "APK: build/app/outputs/flutter-apk/app-release.apk"
