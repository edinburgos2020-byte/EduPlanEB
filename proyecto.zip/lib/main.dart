import 'dart:convert' show base64Encode;
import 'dart:io' show Directory, File;
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart' show CompressFormat, FlutterImageCompress;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource;
import 'package:pdf/pdf.dart' show PdfPageFormat;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart' show Printing;
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' show PdfDocument, PdfTextExtractor;

const compressThresholdBytes = 30 * 1024 * 1024;
const gradeOptions = ['1.º grado', '2.º grado', '3.º grado', '4.º grado', '5.º grado', '6.º grado', '7.º grado', '8.º grado', '9.º grado'];
const subjectOptions = ['Español', 'Matemáticas', 'Ciencias Naturales', 'Ciencias Sociales'];

const supabaseUrl = 'https://vnirdpwvocnuxfogdcpz.supabase.co';
const supabasePublishableKey = 'sb_publishable_PhEUNcr4K5EvfFsN8YUL-Q_kWOkUYNv';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  runApp(const EduPlanEBApp());
}

final supabase = Supabase.instance.client;

class EduPlanEBApp extends StatelessWidget {
  const EduPlanEBApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EduPlanEB',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1769AA),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
      home: const AuthGate(),
    );
  }
}


class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final user = supabase.auth.currentUser;
    final name = (user?.userMetadata?['full_name'] ?? '').toString().trim();
    return Scaffold(
      appBar: AppBar(
        title: const Text('EduPlanEB'),
        actions: [
          IconButton(
            tooltip: 'Mi perfil',
            onPressed: () => _open(context, const TeacherProfilePage()),
            icon: const Icon(Icons.person_outline),
          ),
          IconButton(
            tooltip: 'Cerrar sesión',
            onPressed: () async => supabase.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name.isEmpty ? 'Bienvenido a EduPlanEB' : 'Bienvenido, $name',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  const Text('Del libro a tu planificación, en pocos pasos.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () => _open(context, const CreatePlanPage(planType: 'Plan de clase')),
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Crear planificación con IA'),
          ),
          const SizedBox(height: 14),
          _homeCard(context, 'Planes', 'Crea y consulta tus planificaciones.', Icons.calendar_month_outlined,
              () => _open(context, const PlansMenuPage())),
          _homeCard(context, 'Evaluaciones, rúbricas y guías',
              'Prepara exámenes, rúbricas, guías y listas de cotejo.', Icons.assignment_outlined,
              () => _open(context, const EvaluationPage())),
          _homeCard(context, 'Mis libros', 'Registra libros y abre sus páginas para generar documentos.',
              Icons.menu_book_outlined, () => _open(context, const MyBooksPage())),
          _homeCard(context, 'Mi horario', 'Organiza tus clases por día y período.', Icons.schedule_outlined,
              () => _open(context, const SchedulePage())),
          _homeCard(context, 'Mi matrícula', 'Registra y consulta tus estudiantes.', Icons.groups_outlined,
              () => _open(context, const RosterPage())),
          _homeCard(context, 'Mis documentos', 'Consulta los documentos que has guardado.',
              Icons.folder_copy_outlined, () => _open(context, const DocumentsPage())),
        ],
      ),
    );
  }

  Widget _homeCard(BuildContext context, String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Card(
      child: ListTile(
        leading: Icon(icon, size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (_, __) => supabase.auth.currentSession != null
          ? const HomePage()
          : const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> signInLink() async {
    final value = email.text.trim();
    if (value.isEmpty) return;
    setState(() => loading = true);
    try {
      await supabase.auth.signInWithOtp(email: value);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Revisa tu correo para entrar a EduPlanEB.')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> signInPassword() async {
    final e = email.text.trim();
    final p = password.text;
    if (e.isEmpty || p.isEmpty) return;
    setState(() => loading = true);
    try {
      await supabase.auth.signInWithPassword(email: e, password: p);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo iniciar sesión: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> recoverPassword() async {
    final address = email.text.trim();
    if (address.isEmpty || !address.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escribe primero tu correo electrónico.')));
      return;
    }
    setState(() => loading = true);
    try {
      await supabase.auth.resetPasswordForEmail(address);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Si el correo está registrado, recibirás instrucciones para recuperar tu contraseña.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo solicitar la recuperación: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(children: [

                  const Icon(Icons.school_rounded, size: 76, color: Color(0xFF1769AA)),
                  const SizedBox(height: 10),
                  const Text('EduPlanEB', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                  const Text('Plataforma inteligente para docentes', textAlign: TextAlign.center),
                  const SizedBox(height: 28),
                  TextField(controller: email, keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Correo electrónico', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true,
                    decoration: const InputDecoration(labelText: 'Contraseña (si ya tienes una)', prefixIcon: Icon(Icons.lock_outline))),
                  const SizedBox(height: 16),
                  SizedBox(width: double.infinity, height: 50,
                    child: FilledButton.icon(onPressed: loading ? null : signInPassword,
                      icon: const Icon(Icons.login), label: const Text('Entrar con contraseña'))),
                  const SizedBox(height: 8),
                  SizedBox(width: double.infinity, height: 48,
                    child: OutlinedButton.icon(onPressed: loading ? null : signInLink,
                      icon: const Icon(Icons.mark_email_read_outlined), label: const Text('Recibir enlace por correo'))),
                  TextButton.icon(
                    onPressed: loading ? null : recoverPassword,
                    icon: const Icon(Icons.lock_reset),
                    label: const Text('Olvidé mi contraseña'),
                  ),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 8),
                  SizedBox(width: double.infinity, height: 50,
                    child: FilledButton.icon(
                      onPressed: loading ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterTeacherPage())),
                      icon: const Icon(Icons.person_add_alt_1), label: const Text('Registrar docente'))),
                  const SizedBox(height: 10),
                  const Text('El registro incluye tus datos docentes y del centro educativo.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterTeacherPage extends StatefulWidget {
  const RegisterTeacherPage({super.key});
  @override State<RegisterTeacherPage> createState() => _RegisterTeacherPageState();
}
class _RegisterTeacherPageState extends State<RegisterTeacherPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final center = TextEditingController();
  final municipality = TextEditingController();
  final department = TextEditingController();
  String country = 'Honduras';
  String language = 'es';
  String grade = '4.º grado';
  String subject = 'Español';
  bool loading = false;

  Future<void> register() async {
    if (name.text.trim().isEmpty || email.text.trim().isEmpty || password.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Completa nombre, correo y una contraseña de al menos 6 caracteres.')));
      return;
    }
    setState(() => loading = true);
    try {
      final res = await supabase.auth.signUp(
        email: email.text.trim(),
        password: password.text,
        data: {
          'full_name': name.text.trim(),
          'country': country,
          'language': language,
          'center_name': center.text.trim(),
          'municipality': municipality.text.trim(),
          'department': department.text.trim(),
          'grade': grade,
          'subject': subject,
        },
      );
      if (!mounted) return;
      if (res.session != null) {
        Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomePage()), (_) => false);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Registro creado. Revisa tu correo para confirmar la cuenta y luego inicia sesión.')));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo registrar: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override void dispose() {
    name.dispose(); email.dispose(); password.dispose(); center.dispose(); municipality.dispose(); department.dispose(); super.dispose();
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar docente')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Datos del docente', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre completo *', prefixIcon: Icon(Icons.person_outline))),
        const SizedBox(height: 10),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Correo electrónico *', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 10),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña *', helperText: 'Mínimo 6 caracteres', prefixIcon: Icon(Icons.lock_outline))),
        const SizedBox(height: 18),
        const Text('Datos educativos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(controller: center, decoration: const InputDecoration(labelText: 'Centro educativo')),
        const SizedBox(height: 10),
        TextField(controller: municipality, decoration: const InputDecoration(labelText: 'Municipio')),
        const SizedBox(height: 10),
        TextField(controller: department, decoration: const InputDecoration(labelText: 'Departamento')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: country, decoration: const InputDecoration(labelText: 'País'),
          items: const ['Honduras','Guatemala','El Salvador','Nicaragua','Costa Rica','Panamá','México','Otro'].map((x) => DropdownMenuItem(value:x, child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>country=v!),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: language, decoration: const InputDecoration(labelText: 'Idioma'),
          items: const ['es', 'en', 'fr'].map((x) => DropdownMenuItem(value:x, child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>language=v!),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: grade, decoration: const InputDecoration(labelText: 'Grado principal'),
          items: List.generate(9,(i)=>'${i+1}.º grado').map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>grade=v!),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: subject, decoration: const InputDecoration(labelText: 'Asignatura principal'),
          items: const ['Español','Matemáticas','Ciencias Naturales','Ciencias Sociales'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>subject=v!),
        ),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: loading ? null : register, icon: const Icon(Icons.person_add), label: Text(loading ? 'Registrando...' : 'Crear cuenta de docente')),
      ]),
    );
  }
}


class TeacherProfilePage extends StatefulWidget {
  const TeacherProfilePage({super.key});

  @override
  State<TeacherProfilePage> createState() => _TeacherProfilePageState();
}

class _TeacherProfilePageState extends State<TeacherProfilePage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final specialty = TextEditingController();
  final center = TextEditingController();
  final municipality = TextEditingController();
  final department = TextEditingController();
  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;
      final profile = await supabase.from('profiles').select().eq('id', user.id).maybeSingle();
      final centerRow = await supabase.from('educational_centers').select().eq('owner_id', user.id).limit(1).maybeSingle();
      name.text = (profile?['full_name'] ?? user.userMetadata?['full_name'] ?? '').toString();
      phone.text = (profile?['phone'] ?? '').toString();
      specialty.text = (profile?['specialty'] ?? '').toString();
      center.text = (centerRow?['name'] ?? '').toString();
      municipality.text = (centerRow?['municipality'] ?? '').toString();
      department.text = (centerRow?['department'] ?? '').toString();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo cargar el perfil: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> save() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() => saving = true);
    try {
      await supabase.from('profiles').update({
        'full_name': name.text.trim(),
        'phone': phone.text.trim(),
        'specialty': specialty.text.trim(),
      }).eq('id', user.id);
      final existing = await supabase.from('educational_centers').select('id').eq('owner_id', user.id).limit(1).maybeSingle();
      final data = {'owner_id': user.id, 'name': center.text.trim(), 'municipality': municipality.text.trim(), 'department': department.text.trim()};
      if (existing == null) {
        await supabase.from('educational_centers').insert(data);
      } else {
        await supabase.from('educational_centers').update(data).eq('id', existing['id']);
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Perfil actualizado.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo guardar: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  void dispose() {
    name.dispose(); phone.dispose(); specialty.dispose(); center.dispose(); municipality.dispose(); department.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Mi perfil')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Icon(Icons.account_circle, size: 90),
        const SizedBox(height: 8),
        const Text('Datos del docente', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre completo')),
        const SizedBox(height: 10),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Teléfono')),
        const SizedBox(height: 10),
        TextField(controller: specialty, decoration: const InputDecoration(labelText: 'Especialidad / perfil docente')),
        const SizedBox(height: 18),
        const Text('Centro educativo', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(controller: center, decoration: const InputDecoration(labelText: 'Nombre del centro')),
        const SizedBox(height: 10),
        TextField(controller: municipality, decoration: const InputDecoration(labelText: 'Municipio')),
        const SizedBox(height: 10),
        TextField(controller: department, decoration: const InputDecoration(labelText: 'Departamento')),
        const SizedBox(height: 20),
        FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: Text(saving ? 'Guardando...' : 'Guardar cambios')),
      ]),
    );
  }
}


class BookPagesPage extends StatefulWidget {
  final Map<String, dynamic> book;

  const BookPagesPage({super.key, required this.book});

  @override
  State<BookPagesPage> createState() => _BookPagesPageState();
}

class _BookPagesPageState extends State<BookPagesPage> {
  static const int _maxPages = 30;
  static const int _maxCharsToSend = 12000;

  final pages = TextEditingController(text: '1-5');
  final lesson = TextEditingController();
  final instructions = TextEditingController();
  bool generating = false;
  bool extracting = false;
  String extractedText = '';
  String? notice;

  bool get hasPdf => (widget.book['storage_path'] ?? '').toString().isNotEmpty;

  /// Convierte "10", "10-15" o "3, 5, 10-12" en una lista de páginas (base 1).
  List<int> parsePages(String input, int totalPages) {
    final result = <int>{};
    for (final rawPart in input.split(',')) {
      final part = rawPart.trim();
      if (part.isEmpty) continue;
      final range = part.split('-').map((x) => x.trim()).toList();
      if (range.length > 2) throw const FormatException('Formato de páginas no válido. Usa 10 o 10-15.');
      final start = int.tryParse(range.first);
      final end = int.tryParse(range.last);
      if (start == null || end == null || start < 1 || end < start) {
        throw const FormatException('Formato de páginas no válido. Usa 10 o 10-15.');
      }
      if (start > totalPages) {
        throw FormatException('El PDF tiene $totalPages páginas y pediste la $start.');
      }
      for (var n = start; n <= end && n <= totalPages; n++) {
        result.add(n);
      }
    }
    if (result.isEmpty) throw const FormatException('Indica las páginas que deseas trabajar.');
    if (result.length > _maxPages) {
      throw FormatException('Selecciona como máximo $_maxPages páginas a la vez.');
    }
    final list = result.toList()..sort();
    return list;
  }

  /// Descarga el PDF privado y extrae el texto de las páginas indicadas.
  Future<String> extractFromPdf() async {
    final path = (widget.book['storage_path'] ?? '').toString();
    final Uint8List bytes = await supabase.storage.from('book-files').download(path);
    final document = PdfDocument(inputBytes: bytes);
    try {
      final selected = parsePages(pages.text, document.pages.count);
      final extractor = PdfTextExtractor(document);
      final buffer = StringBuffer();
      for (final n in selected) {
        final text = extractor.extractText(startPageIndex: n - 1, endPageIndex: n - 1).trim();
        if (text.isNotEmpty) {
          buffer.writeln('--- Página $n ---');
          buffer.writeln(text);
          buffer.writeln();
        }
      }
      return buffer.toString().trim();
    } finally {
      document.dispose();
    }
  }

  void showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> analyzePages() async {
    if (!hasPdf) return;
    setState(() {
      extracting = true;
      notice = null;
    });
    try {
      final text = await extractFromPdf();
      if (!mounted) return;
      setState(() {
        extractedText = text;
        notice = text.isEmpty
            ? 'No se encontró texto en esas páginas. Si el PDF es un escaneo (imágenes), hace falta OCR, que llegará en un módulo posterior.'
            : null;
      });
    } on FormatException catch (e) {
      if (mounted) setState(() => notice = e.message);
    } catch (e) {
      if (mounted) setState(() => notice = 'No se pudo leer el PDF: $e');
    } finally {
      if (mounted) setState(() => extracting = false);
    }
  }

  Future<void> createPlan() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    if (pages.text.trim().isEmpty) {
      showMessage('Indica las páginas que deseas trabajar.');
      return;
    }
    setState(() => generating = true);
    try {
      var text = extractedText;
      if (hasPdf && text.isEmpty) {
        text = await extractFromPdf();
        if (!mounted) return;
        setState(() => extractedText = text);
        if (text.isEmpty) {
          setState(() => notice = 'No se encontró texto en esas páginas. Si el PDF es un escaneo (imágenes), hace falta OCR, que llegará en un módulo posterior.');
          return;
        }
      }
      final textToSend = text.length > _maxCharsToSend ? text.substring(0, _maxCharsToSend) : text;
      final result = await supabase.functions.invoke('eduplaneb-generate-plan', body: {
        'plan_type': 'Plan de clase',
        'grade': widget.book['grade'],
        'subject': widget.book['subject'],
        'pages': pages.text.trim(),
        'lesson': lesson.text.trim(),
        'instructions': instructions.text.trim(),
        'book_title': widget.book['title'],
        'extracted_text': textToSend,
      });
      if (result.data is! Map) throw Exception('La función no devolvió un resultado válido.');
      final data = Map<String, dynamic>.from(result.data as Map);
      if (data['ok'] != true) throw Exception(data['error']?.toString() ?? 'No se pudo generar el plan.');
      if (data['content'] is! Map) throw Exception('El plan generado no contiene contenido válido.');
      final content = Map<String, dynamic>.from(data['content'] as Map);
      final inserted = await supabase.from('plans').insert({
        'owner_id': user.id,
        'book_id': widget.book['id'],
        'plan_type': 'lesson',
        'title': 'Plan de clase - ${widget.book['title'] ?? 'Libro'}',
        'pages': pages.text.trim(),
        'lesson': lesson.text.trim(),
        'instructions': instructions.text.trim(),
        'content': content,
        'status': 'generated',
      }).select('id').single();
      content['plan_id'] = inserted['id'];
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratedPlanPage(content: content)));
    } on FormatException catch (e) {
      if (mounted) setState(() => notice = e.message);
    } catch (e) {
      showMessage('No se pudo generar: $e');
    } finally {
      if (mounted) setState(() => generating = false);
    }
  }

  @override
  void dispose() {
    pages.dispose();
    lesson.dispose();
    instructions.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final preview = extractedText.length > 1200 ? '${extractedText.substring(0, 1200)}…' : extractedText;
    return Scaffold(
      appBar: AppBar(title: Text((widget.book['title'] ?? 'Libro').toString())),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Icon(Icons.auto_stories, size: 70),
        Text('Selecciona el contenido', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        Text('Grado: ${widget.book['grade'] ?? ''}'),
        Text('Asignatura: ${widget.book['subject'] ?? ''}'),
        const SizedBox(height: 12),
        TextField(
          controller: pages,
          onChanged: (_) => setState(() {
            extractedText = '';
            notice = null;
          }),
          decoration: const InputDecoration(labelText: 'Páginas (ej. 10 o 10-15)'),
        ),
        const SizedBox(height: 10),
        TextField(controller: lesson, decoration: const InputDecoration(labelText: 'Lección / unidad')),
        const SizedBox(height: 10),
        TextField(controller: instructions, maxLines: 5, decoration: const InputDecoration(labelText: 'Indicaciones para la IA')),
        const SizedBox(height: 14),
        if (hasPdf) ...[
          OutlinedButton.icon(
            onPressed: (extracting || generating) ? null : analyzePages,
            icon: extracting
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.find_in_page_outlined),
            label: Text(extracting ? 'Leyendo PDF...' : 'Analizar páginas del PDF'),
          ),
          const SizedBox(height: 10),
        ] else
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('Este libro no tiene PDF subido. El plan se generará solo con los datos que escribas. Sube el PDF en "Mis libros" para usar el contenido real.'),
            ),
          ),
        if (notice != null)
          Card(
            color: Theme.of(context).colorScheme.errorContainer,
            child: Padding(padding: const EdgeInsets.all(14), child: Text(notice!)),
          ),
        if (extractedText.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Contenido detectado (${extractedText.length} caracteres)', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(preview),
                if (extractedText.length > _maxCharsToSend)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('El texto es largo: se enviará solo la primera parte. Considera elegir menos páginas.', style: TextStyle(fontSize: 12)),
                  ),
              ]),
            ),
          ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: (generating || extracting) ? null : createPlan,
          icon: generating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
          label: Text(generating ? 'Generando...' : 'Generar planificación'),
        ),
      ]),
    );
  }
}





String _safeFileName(String name) {
  const from = 'áàäâãéèëêíìïîóòöôõúùüûñÁÀÄÂÃÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÑ';
  const to = 'aaaaaeeeeiiiiooooouuuunAAAAAEEEEIIIIOOOOOUUUUN';
  final out = StringBuffer();
  for (final ch in name.split('')) {
    final i = from.indexOf(ch);
    out.write(i >= 0 ? to[i] : ch);
  }
  var clean = out.toString().replaceAll(RegExp(r'[^A-Za-z0-9._-]+'), '_');
  clean = clean.replaceAll(RegExp(r'_+'), '_');
  if (!clean.toLowerCase().endsWith('.pdf')) clean = '$clean.pdf';
  if (clean.length > 80) clean = clean.substring(clean.length - 80);
  return clean;
}

String _friendlyUploadError(Object e) {
  final text = e.toString();
  if (text.contains('SocketException') || text.contains('connection abort') || text.contains('Connection closed')) {
    return 'se cortó la conexión. Revisa tu internet o el límite de tamaño en Supabase (Storage → Settings).';
  }
  if (text.contains('413') || text.toLowerCase().contains('too large') || text.toLowerCase().contains('exceeded')) {
    return 'el servidor rechazó el tamaño del archivo. Revisa el límite en Supabase (Storage → Settings) o comprime el PDF.';
  }
  return text.replaceFirst('Exception: ', '');
}

String _rtfEscape(String value) {
  final out = StringBuffer();
  for (final unit in value.codeUnits) {
    if (unit == 0x5C) {
      out.write(r'\\');
    } else if (unit == 0x7B) {
      out.write(r'\{');
    } else if (unit == 0x7D) {
      out.write(r'\}');
    } else if (unit == 0x0A) {
      out.write(r'\line ');
    } else if (unit == 0x0D) {
      // se ignora
    } else if (unit > 126) {
      final signed = unit > 32767 ? unit - 65536 : unit;
      out.write('\\u$signed?');
    } else {
      out.writeCharCode(unit);
    }
  }
  return out.toString();
}

List<MapEntry<String, String>> _exportSections(Map<String, dynamic> content) {
  final type = (content['resource_type'] ?? '').toString();
  if (type == 'Evaluación / examen') {
    return [
      MapEntry('Instrucciones para el estudiante', (content['instructions_for_student'] ?? '').toString()),
      MapEntry('Ítems / preguntas', (content['items'] ?? '').toString()),
      MapEntry('Criterios de evaluación', (content['evaluation_criteria'] ?? '').toString()),
      MapEntry('Clave o respuestas', (content['answer_key'] ?? '').toString()),
    ];
  }
  if (type == 'Rúbrica') {
    return [
      MapEntry('Propósito', (content['purpose'] ?? '').toString()),
      MapEntry('Criterios', (content['criteria'] ?? '').toString()),
      MapEntry('Niveles de desempeño', (content['levels'] ?? '').toString()),
      MapEntry('Evidencias', (content['evidence'] ?? '').toString()),
      MapEntry('Puntaje', (content['score'] ?? '').toString()),
    ];
  }
  if (type == 'Guía de estudio') {
    return [
      MapEntry('Propósito', (content['purpose'] ?? '').toString()),
      MapEntry('Explicación / contenidos', (content['explanation'] ?? '').toString()),
      MapEntry('Actividades', (content['activities'] ?? '').toString()),
      MapEntry('Práctica', (content['practice'] ?? '').toString()),
      MapEntry('Repaso final', (content['review'] ?? '').toString()),
    ];
  }
  if (type == 'Lista de cotejo') {
    return [
      MapEntry('Indicadores', (content['indicators'] ?? '').toString()),
      MapEntry('Opciones de registro', (content['yes_no'] ?? '').toString()),
      MapEntry('Observaciones', (content['observations'] ?? '').toString()),
    ];
  }
  return [
    MapEntry('Propósito de aprendizaje', (content['purpose'] ?? '').toString()),
    MapEntry('Saberes y contenidos', (content['contents'] ?? '').toString()),
    MapEntry('Actividades de inicio', (content['start'] ?? '').toString()),
    MapEntry('Actividades de desarrollo', (content['development'] ?? '').toString()),
    MapEntry('Actividades de cierre', (content['closing'] ?? '').toString()),
    MapEntry('Evaluación', (content['evaluation'] ?? '').toString()),
    MapEntry('Recursos', (content['resources'] ?? '').toString()),
  ];
}

Future<void> exportPlanWord(
  Map<String, dynamic> content, {
  String teacherName = '',
  String centerName = '',
}) async {
  final lines = <String>[
    'EDUPLANEB',
    centerName.isEmpty ? 'Centro educativo' : centerName,
    if (teacherName.isNotEmpty) 'Docente: $teacherName',
    '',
    (content['title'] ?? 'Documento').toString(),
    'Grado: ${(content['grade'] ?? '').toString()}',
    'Asignatura: ${(content['subject'] ?? '').toString()}',
    if ((content['pages'] ?? '').toString().isNotEmpty) 'Páginas: ${(content['pages'] ?? '').toString()}',
    if ((content['lesson'] ?? '').toString().isNotEmpty) 'Tema: ${(content['lesson'] ?? '').toString()}',
    '',
  ];

  for (final entry in _exportSections(content)) {
    lines.add(entry.key.toUpperCase());
    lines.add(entry.value);
    lines.add('');
  }

  final body = lines.map(_rtfEscape).map((line) => '$line\\par').join('\n');
  final rtf = '{\\rtf1\\ansi\\deff0\n$body}';
  final bytes = <int>[...rtf.codeUnits];

  final file = XFile.fromData(
    Uint8List.fromList(bytes),
    name: 'EduPlanEB_documento.rtf',
    mimeType: 'application/rtf',
  );

  await Share.shareXFiles(
    [file],
    subject: 'Documento EduPlanEB',
  );
}

Future<void> exportPlanPdf(
  Map<String, dynamic> content, {
  String teacherName = '',
  String centerName = '',
}) async {
  final doc = pw.Document();

  pw.Widget section(String title, String value) {
    final text = value.trim();
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 10),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(title, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
          pw.SizedBox(height: 3),
          pw.Text(text.isEmpty ? 'Pendiente de completar' : text),
        ],
      ),
    );
  }

  doc.addPage(
    pw.MultiPage(
      margin: const pw.EdgeInsets.all(36),
      build: (_) => [
        pw.Center(
          child: pw.Column(
            children: [
              pw.Text('EDUPLANEB', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text(centerName.isEmpty ? 'Centro educativo' : centerName),
              if (teacherName.isNotEmpty) pw.Text('Docente: $teacherName'),
            ],
          ),
        ),
        pw.Divider(),
        pw.SizedBox(height: 8),
        pw.Center(
          child: pw.Text(
            (content['title'] ?? 'Documento').toString(),
            style: pw.TextStyle(fontSize: 17, fontWeight: pw.FontWeight.bold),
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Text('Grado: ${(content['grade'] ?? '').toString()}'),
        pw.Text('Asignatura: ${(content['subject'] ?? '').toString()}'),
        if ((content['pages'] ?? '').toString().isNotEmpty)
          pw.Text('Páginas: ${(content['pages'] ?? '').toString()}'),
        if ((content['lesson'] ?? '').toString().isNotEmpty)
          pw.Text('Tema: ${(content['lesson'] ?? '').toString()}'),
        pw.SizedBox(height: 15),
        ..._exportSections(content).map((e) => section(e.key, e.value)),
        pw.SizedBox(height: 12),
        pw.Divider(),
        pw.Center(child: pw.Text('Documento generado con EduPlanEB')),
      ],
    ),
  );

  await Printing.layoutPdf(
    onLayout: (_) async => doc.save(),
    name: 'EduPlanEB_documento.pdf',
  );
}

class PlanPrintPreviewPage extends StatelessWidget {
  final Map<String, dynamic> content;
  final String teacherName;
  final String centerName;

  const PlanPrintPreviewPage({
    super.key,
    required this.content,
    this.teacherName = '',
    this.centerName = '',
  });

  Widget row(String label, dynamic value) {
    final text = (value ?? '').toString().trim();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          ),
          const SizedBox(height: 4),
          Text(text.isEmpty ? 'Pendiente de completar' : text),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vista previa del documento'),
        actions: [
          IconButton(
            tooltip: 'Exportar PDF',
            onPressed: () async {
              await exportPlanPdf(
                content,
                teacherName: teacherName,
                centerName: centerName,
              );
            },
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            tooltip: 'Exportar Word',
            onPressed: () async {
              await exportPlanWord(
                content,
                teacherName: teacherName,
                centerName: centerName,
              );
            },
            icon: const Icon(Icons.description_outlined),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Column(
                    children: [
                      const Text(
                        'EDUPLANEB',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        centerName.isEmpty
                            ? 'Centro educativo'
                            : centerName,
                        textAlign: TextAlign.center,
                      ),
                      if (teacherName.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Docente: $teacherName',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ],
                  ),
                ),
                const Divider(height: 30),
                Center(
                  child: Text(
                    (content['title'] ?? 'Planificación').toString(),
                    style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 18),
                Wrap(
                  spacing: 20,
                  runSpacing: 8,
                  children: [
                    Text('Grado: ${(content['grade'] ?? '').toString()}'),
                    Text(
                      'Asignatura: ${(content['subject'] ?? '').toString()}',
                    ),
                    Text('Páginas: ${(content['pages'] ?? '').toString()}'),
                    Text(
                      'Lección: ${(content['lesson'] ?? '').toString()}',
                    ),
                  ],
                ),
                const Divider(height: 28),
                row('Propósito de aprendizaje', content['purpose']),
                row('Saberes y contenidos', content['contents']),
                row('Actividades de inicio', content['start']),
                row('Actividades de desarrollo', content['development']),
                row('Actividades de cierre', content['closing']),
                row('Evaluación', content['evaluation']),
                row('Recursos', content['resources']),
                const SizedBox(height: 20),
                const Divider(),
                const SizedBox(height: 8),
                const Text(
                  'Documento generado con EduPlanEB',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class GeneratedPlanPage extends StatefulWidget {
  final Map<String, dynamic> content;
  const GeneratedPlanPage({super.key, required this.content});

  @override
  State<GeneratedPlanPage> createState() => _GeneratedPlanPageState();
}

class _GeneratedPlanPageState extends State<GeneratedPlanPage> {
  late Map<String, dynamic> content;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    content = Map<String, dynamic>.from(widget.content);
  }

  bool get isResource => (content['resource_type'] ?? '').toString().isNotEmpty;

  String get resourceType => (content['resource_type'] ?? 'Planificación').toString();

  Future<void> saveDocument() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() => saving = true);
    try {
      final planId = content['plan_id']?.toString();
      await supabase.from('documents').insert({
        'owner_id': user.id,
        'plan_id': planId,
        'document_type': isResource ? (content['resource_code'] ?? 'resource') : 'plan',
        'title': content['title']?.toString() ?? 'Documento',
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Documento guardado en Mis documentos.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo guardar el documento: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> edit() async {
    final updated = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(builder: (_) => PlanEditorPage(content: content)),
    );
    if (updated != null && mounted) setState(() => content = updated);
  }

  Future<void> exportPdf() async {
    await exportPlanPdf(content);
  }

  Future<void> exportWord() async {
    await exportPlanWord(content);
  }

  @override
  Widget build(BuildContext context) {
    final sections = content['sections'] is List
        ? (content['sections'] as List).map((e) => e.toString()).toList()
        : <String>[];

    return Scaffold(
      appBar: AppBar(
        title: Text(isResource ? resourceType : 'Plan generado'),
        actions: [
          IconButton(
            onPressed: saving ? null : edit,
            tooltip: 'Editar',
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            onPressed: saving ? null : exportPdf,
            tooltip: 'Exportar PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            onPressed: saving ? null : exportWord,
            tooltip: 'Exportar Word',
            icon: const Icon(Icons.description_outlined),
          ),
          IconButton(
            onPressed: saving ? null : saveDocument,
            tooltip: 'Guardar documento',
            icon: saving
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.folder_copy_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            content['title']?.toString() ?? 'Documento',
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text('${content['grade'] ?? ''} • ${content['subject'] ?? ''}'),
          if ((content['pages'] ?? '').toString().isNotEmpty)
            Text('Páginas: ${content['pages']}'),
          if ((content['lesson'] ?? '').toString().isNotEmpty)
            Text('Tema: ${content['lesson']}'),
          const Divider(height: 28),
          ..._resourceCards(content, isResource),
          if (!isResource)
            ...sections.map(
              (section) => Card(
                child: ListTile(
                  leading: const Icon(Icons.check_circle_outline),
                  title: Text(section),
                  subtitle: const Text('Sección lista para desarrollar y editar.'),
                ),
              ),
            ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: edit,
            icon: const Icon(Icons.edit),
            label: Text(isResource ? 'Editar documento' : 'Editar planificación'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: saving ? null : exportPdf,
            icon: const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('Exportar PDF'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: saving ? null : exportWord,
            icon: const Icon(Icons.description_outlined),
            label: const Text('Exportar Word'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: saving ? null : saveDocument,
            icon: const Icon(Icons.folder_copy_outlined),
            label: const Text('Guardar en Mis documentos'),
          ),
        ],
      ),
    );
  }

  List<Widget> _resourceCards(Map<String, dynamic> c, bool resource) {
    final type = (c['resource_type'] ?? '').toString();
    if (!resource) {
      return [
        if ((c['purpose'] ?? '').toString().isNotEmpty) _section('Propósito de aprendizaje', c['purpose']),
        if ((c['contents'] ?? '').toString().isNotEmpty) _section('Saberes y contenidos', c['contents']),
        if ((c['start'] ?? '').toString().isNotEmpty) _section('Actividades de inicio', c['start']),
        if ((c['development'] ?? '').toString().isNotEmpty) _section('Actividades de desarrollo', c['development']),
        if ((c['closing'] ?? '').toString().isNotEmpty) _section('Actividades de cierre', c['closing']),
        if ((c['evaluation'] ?? '').toString().isNotEmpty) _section('Evaluación', c['evaluation']),
        if ((c['resources'] ?? '').toString().isNotEmpty) _section('Recursos', c['resources']),
      ];
    }

    final entries = <MapEntry<String, dynamic>>[];
    switch (type) {
      case 'Evaluación / examen':
        entries.addAll([
          MapEntry('Instrucciones para el estudiante', c['instructions_for_student']),
          MapEntry('Ítems / preguntas', c['items']),
          MapEntry('Criterios de evaluación', c['evaluation_criteria']),
          MapEntry('Clave o respuestas', c['answer_key']),
        ]);
        break;
      case 'Rúbrica':
        entries.addAll([
          MapEntry('Propósito', c['purpose']),
          MapEntry('Criterios', c['criteria']),
          MapEntry('Niveles de desempeño', c['levels']),
          MapEntry('Evidencias', c['evidence']),
          MapEntry('Puntaje', c['score']),
        ]);
        break;
      case 'Guía de estudio':
        entries.addAll([
          MapEntry('Propósito', c['purpose']),
          MapEntry('Explicación / contenidos', c['explanation']),
          MapEntry('Actividades', c['activities']),
          MapEntry('Práctica', c['practice']),
          MapEntry('Repaso final', c['review']),
        ]);
        break;
      case 'Lista de cotejo':
        entries.addAll([
          MapEntry('Indicadores', c['indicators']),
          MapEntry('Opciones de registro', c['yes_no']),
          MapEntry('Observaciones', c['observations']),
        ]);
        break;
    }
    return entries
        .where((e) => (e.value ?? '').toString().trim().isNotEmpty)
        .map((e) => _section(e.key, e.value))
        .toList();
  }

  Widget _section(String title, dynamic value) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text((value ?? '').toString()),
            ],
          ),
        ),
      );
}


class PlanEditorPage extends StatefulWidget {
  final Map<String, dynamic> content;
  const PlanEditorPage({super.key, required this.content});

  @override
  State<PlanEditorPage> createState() => _PlanEditorPageState();
}

class _PlanEditorPageState extends State<PlanEditorPage> {
  late Map<String, TextEditingController> fields;

  List<MapEntry<String, String>> _labelsFor(Map<String, dynamic> content) {
    final type = (content['resource_type'] ?? '').toString();
    if (type == 'Evaluación / examen') {
      return const [
        MapEntry('instructions_for_student', 'Instrucciones para el estudiante'),
        MapEntry('items', 'Ítems / preguntas'),
        MapEntry('evaluation_criteria', 'Criterios de evaluación'),
        MapEntry('answer_key', 'Clave o respuestas'),
      ];
    }
    if (type == 'Rúbrica') {
      return const [
        MapEntry('purpose', 'Propósito'),
        MapEntry('criteria', 'Criterios'),
        MapEntry('levels', 'Niveles de desempeño'),
        MapEntry('evidence', 'Evidencias'),
        MapEntry('score', 'Puntaje'),
      ];
    }
    if (type == 'Guía de estudio') {
      return const [
        MapEntry('purpose', 'Propósito'),
        MapEntry('explanation', 'Explicación / contenidos'),
        MapEntry('activities', 'Actividades'),
        MapEntry('practice', 'Práctica'),
        MapEntry('review', 'Repaso final'),
      ];
    }
    if (type == 'Lista de cotejo') {
      return const [
        MapEntry('indicators', 'Indicadores'),
        MapEntry('yes_no', 'Opciones de registro'),
        MapEntry('observations', 'Observaciones'),
      ];
    }
    return const [
      MapEntry('purpose', 'Propósito de aprendizaje'),
      MapEntry('contents', 'Saberes y contenidos'),
      MapEntry('start', 'Actividades de inicio'),
      MapEntry('development', 'Actividades de desarrollo'),
      MapEntry('closing', 'Actividades de cierre'),
      MapEntry('evaluation', 'Evaluación'),
      MapEntry('resources', 'Recursos'),
    ];
  }

  @override
  void initState() {
    super.initState();
    final labels = _labelsFor(widget.content);
    fields = {
      for (final entry in labels)
        entry.key: TextEditingController(text: widget.content[entry.key]?.toString() ?? ''),
    };
  }

  @override
  void dispose() {
    for (final controller in fields.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> save() async {
    final updated = Map<String, dynamic>.from(widget.content);
    for (final entry in fields.entries) {
      updated[entry.key] = entry.value.text.trim();
    }

    final user = supabase.auth.currentUser;
    final planId = updated['plan_id']?.toString();

    try {
      if (user != null && planId != null && planId.isNotEmpty) {
        await supabase
            .from('plans')
            .update({'content': updated, 'status': 'draft'})
            .eq('id', planId)
            .eq('owner_id', user.id);
      }
      if (mounted) Navigator.pop(context, updated);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo guardar: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isResource = (widget.content['resource_type'] ?? '').toString().isNotEmpty;
    return Scaffold(
      appBar: AppBar(
        title: Text(isResource ? 'Editar documento' : 'Editar planificación'),
        actions: [IconButton(onPressed: save, icon: const Icon(Icons.save))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            widget.content['title']?.toString() ?? 'Documento',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 16),
          ...fields.entries.map(
            (entry) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: entry.value,
                minLines: 3,
                maxLines: 10,
                decoration: InputDecoration(
                  labelText: _labelsFor(widget.content)
                      .firstWhere((e) => e.key == entry.key)
                      .value,
                  alignLabelWithHint: true,
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
          ),
          FilledButton.icon(
            onPressed: save,
            icon: const Icon(Icons.save),
            label: const Text('Guardar cambios'),
          ),
        ],
      ),
    );
  }
}

class CreatePlanPage extends StatefulWidget {
  final String planType;
  const CreatePlanPage({super.key, required this.planType});
  @override State<CreatePlanPage> createState() => _CreatePlanPageState();
}
class _CreatePlanPageState extends State<CreatePlanPage> {
  final pages = TextEditingController();
  final lesson = TextEditingController();
  final instructions = TextEditingController();
  final sourceText = TextEditingController();
  String grade = '4.º grado';
  String subject = 'Español';
  bool saving = false;
  bool generating = false;
  bool automaticMode = false;
  List<Map<String, dynamic>> scheduleRows = [];
  String distribution = '';
  final distributionController = TextEditingController();
  final photos = <Uint8List>[];
  final _picker = ImagePicker();
  static const maxPhotos = 10;

  String _mimeOf(Uint8List b) => (b.length > 3 && b[0] == 0x89 && b[1] == 0x50) ? 'image/png' : 'image/jpeg';

  Future<void> _addPhoto(ImageSource source) async {
    final room = maxPhotos - photos.length;
    if (room <= 0) return;
    try {
      final List<XFile> picked;
      if (source == ImageSource.camera) {
        final one = await _picker.pickImage(source: source, maxWidth: 1600, imageQuality: 70);
        picked = one == null ? <XFile>[] : <XFile>[one];
      } else {
        picked = await _picker.pickMultiImage(maxWidth: 1600, imageQuality: 70);
      }
      for (final f in picked.take(room)) {
        photos.add(await f.readAsBytes());
      }
      if (!mounted) return;
      setState(() {});
      if (picked.length > room) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Solo se pueden usar 10 fotos por plan.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo obtener la foto: $e')));
    }
  }

  Widget _photoSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Fotos del libro o material (opcional)', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      const Text('Toma o elige hasta 10 fotos de las páginas. La IA las leerá y las usará para armar el plan. Procura buena luz y que el texto se vea nítido.'),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton.icon(
          onPressed: photos.length >= maxPhotos ? null : () => _addPhoto(ImageSource.camera),
          icon: const Icon(Icons.photo_camera), label: const Text('Tomar foto'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(
          onPressed: photos.length >= maxPhotos ? null : () => _addPhoto(ImageSource.gallery),
          icon: const Icon(Icons.photo_library), label: const Text('Galería'))),
      ]),
      if (photos.isNotEmpty) ...[
        const SizedBox(height: 10),
        SizedBox(
          height: 100,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: photos.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => Stack(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.memory(photos[i], width: 80, height: 100, fit: BoxFit.cover),
              ),
              Positioned(
                top: 0, right: 0,
                child: InkWell(
                  onTap: () => setState(() => photos.removeAt(i)),
                  child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close, size: 14, color: Colors.white)),
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 4),
        Text('${photos.length} de $maxPhotos fotos'),
      ],
    ]);
  }

  Future<void> generateWithAI() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() => generating = true);
    try {
      final result = await supabase.functions.invoke('eduplaneb-generate-plan', body: {
        'plan_type': widget.planType, 'grade': grade, 'subject': subject,
        'pages': pages.text.trim(), 'lesson': lesson.text.trim(), 'instructions': instructions.text.trim(), 'source_text': sourceText.text.trim(), 'mode': automaticMode ? 'automatic' : 'manual', 'schedule': scheduleRows, 'distribution': distribution,
        'images': photos.map((b) => 'data:${_mimeOf(b)};base64,${base64Encode(b)}').toList(),
      });
      if (result.data is! Map) throw Exception('La función no devolvió un resultado válido.');
      final data = Map<String, dynamic>.from(result.data as Map);
      if (data['ok'] != true) throw Exception(data['error']?.toString() ?? 'No se pudo generar el plan.');
      if (data['content'] is! Map) throw Exception('El plan generado no contiene contenido válido.');
      final content = Map<String, dynamic>.from(data['content'] as Map);
      await supabase.from('plans').insert({
        'owner_id': user.id, 'plan_type': _planCode(widget.planType), 'title': widget.planType,
        'pages': pages.text.trim(), 'lesson': lesson.text.trim(), 'instructions': instructions.text.trim(),
        'content': content, 'status': 'generated'
      });
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => GeneratedPlanPage(content: content)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo generar: $e')));
    } finally { if (mounted) setState(() => generating = false); }
  }
  Future<void> _loadScheduleSuggestion() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final rows = await supabase
          .from('teacher_schedule')
          .select('day,period,grade,subject')
          .eq('owner_id', user.id)
          .order('day')
          .order('period');

      if (rows.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Todavía no tienes clases registradas en tu horario.')),
          );
        }
        return;
      }

      final loaded = rows.map((e) => Map<String, dynamic>.from(e)).toList();
      final matching = loaded.where((r) {
        final g = (r['grade'] ?? '').toString();
        final sub = (r['subject'] ?? '').toString();
        return (g.isEmpty || g == grade) && (sub.isEmpty || sub == subject);
      }).toList();

      final usable = matching.isNotEmpty ? matching : loaded;
      final lines = usable.map((r) {
        return '${r['day'] ?? ''} — período ${r['period'] ?? ''}';
      }).join('\n');

      setState(() {
        scheduleRows = usable;
        distribution = automaticMode
            ? 'Propuesta automática pendiente de generar:\n$lines'
            : distribution;
        distributionController.text = distribution;
        if (usable.isNotEmpty) {
          final g = (usable.first['grade'] ?? '').toString();
          final sub = (usable.first['subject'] ?? '').toString();
          if (gradeOptions.contains(g)) grade = g;
          if (subjectOptions.contains(sub)) subject = sub;
        }
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${usable.length} clase(s) tomadas del horario.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo leer el horario: $e')),
        );
      }
    }
  }

  void _prepareAutomaticDistribution() {
    if (scheduleRows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Primero carga tu horario.')),
      );
      return;
    }
    // The teacher can provide multiple topics separated by newlines or semicolons.
    // When there are more classes than topics, the final topic is used for review.
    final topics = lesson.text.split(RegExp(r'[;\n]+'))
        .map((t) => t.trim()).where((t) => t.isNotEmpty).toList();
    if (topics.isEmpty) topics.add('Contenido por definir');
    final lines = <String>[];
    for (var i = 0; i < scheduleRows.length; i++) {
      final r = scheduleRows[i];
      final day = (r['day'] ?? '').toString();
      final period = (r['period'] ?? '').toString();
      final topicIndex = (i * topics.length ~/ scheduleRows.length);
      lines.add('${i + 1}. $day — período $period: ${topics[topicIndex]}');
    }
    setState(() {
      distribution = lines.join('\n');
      distributionController.text = distribution;
    });
  }

  Future<void> saveDraft() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() => saving = true);
    try {
      await supabase.from('plans').insert({
        'owner_id': user.id, 'plan_type': _planCode(widget.planType),
        'title': widget.planType, 'pages': pages.text.trim(), 'lesson': lesson.text.trim(),
        'instructions': instructions.text.trim(),
        'content': {'grade': grade, 'subject': subject, 'mode': automaticMode ? 'automatic' : 'manual', 'distribution': distribution, 'status': 'draft'},
        'status': 'draft'
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Borrador guardado.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo guardar: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }
  String _planCode(String t) {
    if (t == 'Plan semanal') return 'weekly';
    if (t == 'Plan mensual') return 'monthly';
    if (t == 'Plan de clase') return 'lesson';
    if (t == 'Plan remedial') return 'remedial';
    if (t == 'Plan de recuperación') return 'recovery';
    return 'custom';
  }
  @override void dispose() {
    distributionController.dispose(); pages.dispose(); lesson.dispose(); instructions.dispose(); sourceText.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.planType)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('1. Datos básicos', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: grade, decoration: const InputDecoration(labelText: 'Grado'),
          items: List.generate(9, (i) => DropdownMenuItem(value: '${i+1}.º grado', child: Text('${i+1}.º grado'))),
          onChanged: (v) => setState(() => grade = v!),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: subject, decoration: const InputDecoration(labelText: 'Asignatura'),
          items: const ['Español','Matemáticas','Ciencias Naturales','Ciencias Sociales'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
          onChanged: (v) => setState(() => subject = v!),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: _loadScheduleSuggestion, icon: const Icon(Icons.schedule), label: const Text('Usar mi horario')),
        const SizedBox(height: 10),
        TextField(controller: pages, decoration: const InputDecoration(labelText: 'Páginas del libro', hintText: 'Ejemplo: 25-30')),
        const SizedBox(height: 12),
        TextField(controller: lesson, decoration: const InputDecoration(labelText: 'Lección / unidad / contenido')),
        const SizedBox(height: 12),
        TextField(controller: sourceText, minLines: 4, maxLines: 9, decoration: const InputDecoration(labelText: 'Contenido del libro o material (opcional)', hintText: 'Pega aquí el texto de las páginas si ya lo tienes.')),
        const SizedBox(height: 12),
        _photoSection(),
        const SizedBox(height: 12),
        const Text('2. ¿Cómo quieres que trabaje EduPlanEB?', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          child: RadioListTile<bool>(
            value: false,
            groupValue: automaticMode,
            onChanged: (v) => setState(() => automaticMode = v ?? false),
            title: const Text('Modo manual'),
            subtitle: const Text('Tú decides qué contenido corresponde a cada clase y puedes editarlo.'),
          ),
        ),
        Card(
          child: RadioListTile<bool>(
            value: true,
            groupValue: automaticMode,
            onChanged: (v) {
              setState(() => automaticMode = v ?? false);
              if (automaticMode && scheduleRows.isNotEmpty) _prepareAutomaticDistribution();
            },
            title: const Text('Modo automático'),
            subtitle: const Text('EduPlanEB propone la distribución usando tu horario. Después puedes modificarla.'),
          ),
        ),
        const SizedBox(height: 8),
        Text('Clases disponibles: ${scheduleRows.length}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        if (automaticMode)
          OutlinedButton.icon(
            onPressed: _prepareAutomaticDistribution,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Proponer distribución automática'),
          ),
        TextField(
          controller: distributionController,
          minLines: 3,
          maxLines: 8,
          onChanged: (v) => distribution = v,
          decoration: const InputDecoration(
            labelText: 'Distribución de contenidos (editable)',
            hintText: 'Manual: escribe por día. Automático: revisa la propuesta.',
          ),
        ),
        TextField(controller: instructions, maxLines: 5,
          decoration: const InputDecoration(labelText: 'Instrucciones adicionales', hintText: 'Escribe libremente cómo quieres tu documento...')),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: saving ? null : saveDraft, icon: const Icon(Icons.save), label: Text(saving ? 'Guardando...' : 'Guardar borrador')),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: generating ? null : generateWithAI, icon: const Icon(Icons.auto_awesome), label: Text(generating ? 'Generando...' : 'Generar con IA')),
      ]),
    );
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override Widget build(BuildContext context) {
    final books = [
      ['Leo y Escribo', 'Material de lectura y escritura', 'Honduras'],
      ['Guías GANE', 'Guías de apoyo educativo', 'Honduras'],
      ['De Lectores a Líderes', 'Comprensión y fluidez', 'Honduras'],
    ];
    return Scaffold(appBar: AppBar(title: const Text('Biblioteca')), body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Biblioteca educativa', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('La biblioteca oficial se ampliará por país, grado y asignatura.'),
      const SizedBox(height: 16),
      ...books.map((b) => Card(child: ListTile(leading: const Icon(Icons.menu_book_rounded), title: Text(b[0]), subtitle: Text('${b[1]}\n${b[2]}'), isThreeLine: true))),
    ]));
  }
}

class MyBooksPage extends StatefulWidget {
  const MyBooksPage({super.key});

  @override
  State<MyBooksPage> createState() => _MyBooksPageState();
}

class _MyBooksPageState extends State<MyBooksPage> {
  bool loading = true;
  bool saving = false;
  List<Map<String, dynamic>> books = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;
      final data = await supabase.from('books').select().eq('owner_id', user.id).order('created_at', ascending: false);
      if (mounted) setState(() => books = List<Map<String, dynamic>>.from(data));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudieron cargar los libros: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<Map<String, String>?> bookDialog({bool pdf = false, String? defaultTitle}) async {
    final title = TextEditingController(text: defaultTitle ?? '');
    final grade = TextEditingController();
    final subject = TextEditingController();
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(pdf ? 'Datos del libro PDF' : 'Registrar libro'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Título del libro *')),
          const SizedBox(height: 10),
          TextField(controller: grade, decoration: const InputDecoration(labelText: 'Grado *')),
          const SizedBox(height: 10),
          TextField(controller: subject, decoration: const InputDecoration(labelText: 'Asignatura *')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () {
            if (title.text.trim().isEmpty || grade.text.trim().isEmpty || subject.text.trim().isEmpty) return;
            Navigator.pop(context, {'title': title.text.trim(), 'grade': grade.text.trim(), 'subject': subject.text.trim()});
          }, child: const Text('Guardar')),
        ],
      ),
    );
    title.dispose(); grade.dispose(); subject.dispose();
    return result;
  }

  Future<void> addBook() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    final data = await bookDialog();
    if (data == null) return;
    setState(() => saving = true);
    try {
      await supabase.from('books').insert({
        'owner_id': user.id, 'title': data['title'], 'country': 'Honduras', 'language': 'es',
        'grade': data['grade'], 'subject': data['subject'], 'source_type': 'personal',
      });
      await load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Libro registrado.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<String?> _askCompress(double mb) {
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('PDF pesado'),
        content: Text(
          'Este PDF pesa ${mb.toStringAsFixed(0)} MB. Puedes comprimirlo para que suba más rápido y ocupe menos espacio.\n\n'
          'Al comprimir, las páginas se convierten en imágenes: el libro se ve igual, pero ya no se podrá seleccionar ni leer el texto del PDF. '
          'Puede tardar varios minutos.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'cancel'), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'asis'), child: const Text('Subir sin comprimir')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'compress'), child: const Text('Comprimir')),
        ],
      ),
    );
  }

  /// Convierte cada página a JPEG liviano y arma un PDF nuevo. Devuelve null si se cancela.
  Future<File?> _compressPdf(String inputPath) async {
    const dpi = 110.0;
    var cancelled = false;
    final pagesDone = ValueNotifier<int>(0);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: const Text('Comprimiendo PDF'),
          content: ValueListenableBuilder<int>(
            valueListenable: pagesDone,
            builder: (_, n, __) => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const LinearProgressIndicator(),
                const SizedBox(height: 14),
                Text(n == 0 ? 'Preparando el archivo...' : 'Páginas procesadas: $n'),
                const SizedBox(height: 6),
                const Text('No cierres la app mientras termina.'),
              ],
            ),
          ),
          actions: [TextButton(onPressed: () => cancelled = true, child: const Text('Cancelar'))],
        ),
      ),
    );
    try {
      final input = await File(inputPath).readAsBytes();
      final doc = pw.Document(compress: true);
      await for (final page in Printing.raster(input, dpi: dpi)) {
        if (cancelled) return null;
        final png = await page.toPng();
        final jpg = await FlutterImageCompress.compressWithList(
          png,
          minWidth: 4000,
          minHeight: 4000,
          quality: 60,
          format: CompressFormat.jpeg,
        );
        final format = PdfPageFormat(page.width * 72 / dpi, page.height * 72 / dpi);
        final image = pw.MemoryImage(jpg);
        doc.addPage(pw.Page(
          pageFormat: format,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
        ));
        pagesDone.value = pagesDone.value + 1;
      }
      if (cancelled || pagesDone.value == 0) return null;
      final out = File('${Directory.systemTemp.path}/comprimido_${DateTime.now().millisecondsSinceEpoch}.pdf');
      await out.writeAsBytes(await doc.save());
      return out;
    } finally {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      pagesDone.dispose();
    }
  }

  Future<void> uploadBook() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final picked = await FilePicker.platform.pickFiles(withData: false, type: FileType.custom, allowedExtensions: ['pdf']);
      if (picked == null) return;
      final file = picked.files.single;
      final filePath = file.path;
      if (filePath == null) throw Exception('No se pudo leer el archivo.');
      final baseTitle = file.name.toLowerCase().endsWith('.pdf') ? file.name.substring(0, file.name.length - 4) : file.name;
      final data = await bookDialog(pdf: true, defaultTitle: baseTitle);
      if (data == null) return;
      setState(() => saving = true);
      const maxBytes = 250 * 1024 * 1024;
      if (file.size > maxBytes) {
        final mb = (file.size / 1024 / 1024).toStringAsFixed(1);
        throw Exception('El PDF pesa $mb MB y el límite es 250 MB. Comprímelo e inténtalo de nuevo.');
      }
      var uploadFile = File(filePath);
      File? tempFile;
      if (file.size > compressThresholdBytes) {
        final choice = await _askCompress(file.size / 1024 / 1024);
        if (choice == null || choice == 'cancel') return;
        if (choice == 'compress') {
          final compressed = await _compressPdf(filePath);
          if (compressed == null) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Compresión cancelada. No se subió nada.')));
            return;
          }
          final newSize = await compressed.length();
          if (newSize < file.size) {
            tempFile = compressed;
            uploadFile = compressed;
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('Comprimido de ${(file.size / 1024 / 1024).toStringAsFixed(1)} MB a ${(newSize / 1024 / 1024).toStringAsFixed(1)} MB. Subiendo...'),
              ));
            }
          } else {
            await compressed.delete();
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('La compresión no redujo el tamaño. Se subirá el original.')));
          }
        }
      }
      final path = '${user.id}/${DateTime.now().millisecondsSinceEpoch}_${_safeFileName(file.name)}';
      try {
        await supabase.storage.from('book-files').upload(
              path,
              uploadFile,
              fileOptions: const FileOptions(contentType: 'application/pdf'),
            );
      } finally {
        if (tempFile != null) {
          try {
            await tempFile.delete();
          } catch (_) {}
        }
      }
      await supabase.from('books').insert({
        'owner_id': user.id, 'title': data['title'], 'country': 'Honduras', 'language': 'es',
        'grade': data['grade'], 'subject': data['subject'], 'source_type': 'personal',
        'storage_path': path, 'file_name': file.name,
      });
      await load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF subido correctamente.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo subir: ${_friendlyUploadError(e)}')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis libros')),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Registrar material propio', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: saving ? null : addBook, icon: const Icon(Icons.add), label: const Text('Registrar libro')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: saving ? null : uploadBook, icon: const Icon(Icons.picture_as_pdf), label: Text(saving ? 'Procesando...' : 'Subir libro en PDF')),
        const SizedBox(height: 20),
        const Text('Mis materiales', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (books.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Todavía no tienes libros registrados.'))),
        ...books.map((book) => Card(child: ListTile(
          leading: const Icon(Icons.book),
          title: Text('${book['title'] ?? ''}'),
          subtitle: Text('${book['grade'] ?? ''} • ${book['subject'] ?? ''}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookPagesPage(book: book))),
        ))),
      ]),
    );
  }
}


class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePageState();
}

class _SchedulePageState extends State<SchedulePage> {
  final day = TextEditingController();
  final subject = TextEditingController();
  final grade = TextEditingController();
  final period = TextEditingController();
  final rows = <Map<String, dynamic>>[];
  bool loading = true;
  bool saving = false;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;
      final data = await supabase.from('teacher_schedule').select().eq('owner_id', user.id).order('day');
      if (mounted) setState(() { rows..clear()..addAll(List<Map<String, dynamic>>.from(data)); });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo cargar el horario: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> add() async {
    final user = supabase.auth.currentUser;
    if (user == null || subject.text.trim().isEmpty) return;
    setState(() => saving = true);
    try {
      await supabase.from('teacher_schedule').insert({'owner_id': user.id, 'day': day.text.trim(), 'period': period.text.trim(), 'subject': subject.text.trim(), 'grade': grade.text.trim()});
      day.clear(); period.clear(); subject.clear(); grade.clear(); await load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
    finally { if (mounted) setState(() => saving = false); }
  }

  @override
  void dispose() { day.dispose(); subject.dispose(); grade.dispose(); period.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi horario')),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Horario docente', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('Este horario se utilizará para distribuir contenidos en los planes.'),
        const SizedBox(height: 14),
        TextField(controller: day, decoration: const InputDecoration(labelText: 'Día', hintText: 'Lunes')),
        const SizedBox(height: 8), TextField(controller: period, decoration: const InputDecoration(labelText: 'Hora / período')),
        const SizedBox(height: 8), TextField(controller: grade, decoration: const InputDecoration(labelText: 'Grado')),
        const SizedBox(height: 8), TextField(controller: subject, decoration: const InputDecoration(labelText: 'Asignatura')),
        const SizedBox(height: 10), FilledButton.icon(onPressed: saving ? null : add, icon: const Icon(Icons.add), label: Text(saving ? 'Guardando...' : 'Agregar al horario')),
        const SizedBox(height: 16),
        ...rows.map((row) => Card(child: ListTile(leading: const Icon(Icons.schedule), title: Text('${row['day'] ?? ''} • ${row['period'] ?? ''}'), subtitle: Text('${row['grade'] ?? ''} — ${row['subject'] ?? ''}')))),
      ]),
    );
  }
}


class RosterPage extends StatefulWidget {
  const RosterPage({super.key});

  @override
  State<RosterPage> createState() => _RosterPageState();
}

class _RosterPageState extends State<RosterPage> {
  final name = TextEditingController();
  final code = TextEditingController();
  final students = <Map<String, dynamic>>[];
  bool loading = true;
  bool saving = false;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;
      final data = await supabase.from('student_rosters').select().eq('owner_id', user.id).order('student_name');
      if (mounted) setState(() { students..clear()..addAll(List<Map<String, dynamic>>.from(data)); });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo cargar la matrícula: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> add() async {
    final user = supabase.auth.currentUser;
    if (user == null || name.text.trim().isEmpty) return;
    setState(() => saving = true);
    try {
      await supabase.from('student_rosters').insert({'owner_id': user.id, 'student_name': name.text.trim(), 'student_code': code.text.trim()});
      name.clear(); code.clear(); await load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
    finally { if (mounted) setState(() => saving = false); }
  }

  @override
  void dispose() { name.dispose(); code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi matrícula')),
      body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Registro opcional de estudiantes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre del estudiante')),
        const SizedBox(height: 8), TextField(controller: code, decoration: const InputDecoration(labelText: 'Código (opcional)')),
        const SizedBox(height: 10), FilledButton.icon(onPressed: saving ? null : add, icon: const Icon(Icons.person_add), label: Text(saving ? 'Guardando...' : 'Agregar estudiante')),
        const SizedBox(height: 16),
        ...students.asMap().entries.map((entry) => Card(child: ListTile(
          leading: CircleAvatar(child: Text('${entry.key + 1}')),
          title: Text('${entry.value['student_name'] ?? ''}'),
          subtitle: Text((entry.value['student_code'] ?? '').toString().isEmpty ? 'Sin código' : '${entry.value['student_code']}'),
        ))),
      ]),
    );
  }
}


void _comingSoon(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('Módulo de generación IA: siguiente etapa de desarrollo.')),
  );
}


class EvaluationPage extends StatelessWidget {
  const EvaluationPage({super.key});

  Widget _tool(BuildContext context, String title, String subtitle, IconData icon, String type) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ResourceCreatePage(resourceType: type)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Evaluaciones, rúbricas y guías')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Selecciona el documento que quieres preparar',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          _tool(context, 'Evaluación / examen', 'Crea preguntas a partir del contenido seleccionado.', Icons.quiz_outlined, 'Evaluación / examen'),
          _tool(context, 'Guía de estudio', 'Organiza contenidos y actividades de repaso.', Icons.menu_book_outlined, 'Guía de estudio'),
          _tool(context, 'Rúbrica', 'Define criterios, niveles y evidencias.', Icons.fact_check_outlined, 'Rúbrica'),
          _tool(context, 'Lista de cotejo', 'Prepara indicadores para observar el desempeño.', Icons.checklist, 'Lista de cotejo'),
        ],
      ),
    );
  }
}

class ResourceCreatePage extends StatefulWidget {
  final String resourceType;
  const ResourceCreatePage({super.key, required this.resourceType});

  @override
  State<ResourceCreatePage> createState() => _ResourceCreatePageState();
}

class _ResourceCreatePageState extends State<ResourceCreatePage> {
  final pages = TextEditingController();
  final topic = TextEditingController();
  final instructions = TextEditingController();
  final sourceText = TextEditingController();
  String grade = '4.º grado';
  String subject = 'Español';
  bool generating = false;
  bool saving = false;

  String _code(String type) {
    switch (type) {
      case 'Evaluación / examen':
        return 'evaluation';
      case 'Rúbrica':
        return 'rubric';
      case 'Guía de estudio':
        return 'study_guide';
      case 'Lista de cotejo':
        return 'checklist';
      default:
        return 'resource';
    }
  }

  Future<void> generate() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    if (topic.text.trim().isEmpty && pages.text.trim().isEmpty && instructions.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Indica al menos el contenido, las páginas o una instrucción.')),
      );
      return;
    }

    setState(() => generating = true);
    try {
      final result = await supabase.functions.invoke(
        'eduplaneb-generate-plan',
        body: {
          'plan_type': widget.resourceType,
          'grade': grade,
          'subject': subject,
          'pages': pages.text.trim(),
          'lesson': topic.text.trim(),
          'instructions': instructions.text.trim(),
          'source_text': sourceText.text.trim(),
        },
      );

      if (result.data is! Map) throw Exception('La función no devolvió un resultado válido.');
      final data = Map<String, dynamic>.from(result.data as Map);
      if (data['ok'] != true) {
        throw Exception(data['error']?.toString() ?? 'No se pudo generar el documento.');
      }
      if (data['content'] is! Map) throw Exception('El documento generado no contiene contenido válido.');

      final content = Map<String, dynamic>.from(data['content'] as Map);
      content['resource_type'] = widget.resourceType;
      content['resource_code'] = _code(widget.resourceType);
      content['title'] = _resourceTitle(widget.resourceType, topic.text.trim());
      content['grade'] = grade;
      content['subject'] = subject;
      content['pages'] = pages.text.trim();
      content['lesson'] = topic.text.trim();
      content['instructions'] = instructions.text.trim();

      _applyResourceTemplate(content, widget.resourceType);

      final inserted = await supabase.from('plans').insert({
        'owner_id': user.id,
        'plan_type': _code(widget.resourceType),
        'title': content['title'],
        'pages': pages.text.trim(),
        'lesson': topic.text.trim(),
        'instructions': instructions.text.trim(),
        'content': content,
        'status': 'generated',
      }).select('id').single();

      content['plan_id'] = inserted['id'];

      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => GeneratedPlanPage(content: content)),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo generar: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => generating = false);
    }
  }

  Future<void> saveDraft() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    setState(() => saving = true);
    try {
      await supabase.from('plans').insert({
        'owner_id': user.id,
        'plan_type': _code(widget.resourceType),
        'title': widget.resourceType,
        'pages': pages.text.trim(),
        'lesson': topic.text.trim(),
        'instructions': instructions.text.trim(),
        'content': {
          'resource_type': widget.resourceType,
          'resource_code': _code(widget.resourceType),
          'title': widget.resourceType,
          'grade': grade,
          'subject': subject,
          'pages': pages.text.trim(),
          'lesson': topic.text.trim(),
          'instructions': instructions.text.trim(),
          'status': 'draft',
        },
        'status': 'draft',
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Borrador guardado.')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo guardar: $e')),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  void dispose() {
    pages.dispose();
    topic.dispose();
    instructions.dispose();
    sourceText.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final type = widget.resourceType;
    return Scaffold(
      appBar: AppBar(title: Text(type)),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'Datos del documento',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: grade,
            decoration: const InputDecoration(labelText: 'Grado'),
            items: List.generate(
              9,
              (i) => DropdownMenuItem(
                value: '${i + 1}.º grado',
                child: Text('${i + 1}.º grado'),
              ),
            ),
            onChanged: (v) => setState(() => grade = v!),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: subject,
            decoration: const InputDecoration(labelText: 'Asignatura'),
            items: const [
              'Español',
              'Matemáticas',
              'Ciencias Naturales',
              'Ciencias Sociales',
            ].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
            onChanged: (v) => setState(() => subject = v!),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: pages,
            decoration: const InputDecoration(
              labelText: 'Páginas del libro',
              hintText: 'Ejemplo: 25-30',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: topic,
            decoration: const InputDecoration(
              labelText: 'Contenido, lección o tema',
              hintText: 'Ejemplo: sustantivos propios y comunes',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: sourceText,
            minLines: 4,
            maxLines: 10,
            decoration: const InputDecoration(
              labelText: 'Contenido del libro o material (opcional)',
              hintText: 'Pega aquí el texto de las páginas si ya lo tienes.',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: instructions,
            minLines: 5,
            maxLines: 8,
            decoration: InputDecoration(
              labelText: 'Instrucciones adicionales',
              hintText: _resourceHint(type),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: generating ? null : generate,
            icon: generating
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome),
            label: Text(generating ? 'Generando...' : 'Generar con IA'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: saving ? null : saveDraft,
            icon: const Icon(Icons.save_outlined),
            label: Text(saving ? 'Guardando...' : 'Guardar borrador'),
          ),
        ],
      ),
    );
  }
}

String _resourceTitle(String type, String topic) {
  if (topic.trim().isEmpty) return type;
  switch (type) {
    case 'Evaluación / examen':
      return 'Evaluación: $topic';
    case 'Guía de estudio':
      return 'Guía de estudio: $topic';
    case 'Rúbrica':
      return 'Rúbrica: $topic';
    case 'Lista de cotejo':
      return 'Lista de cotejo: $topic';
    default:
      return topic;
  }
}

String _resourceHint(String type) {
  switch (type) {
    case 'Evaluación / examen':
      return 'Indica cantidad de preguntas, tipos de ítems, valor, dificultad o contenidos que deben aparecer.';
    case 'Rúbrica':
      return 'Indica el producto o desempeño que se evaluará y, si quieres, los criterios que ya tienes definidos.';
    case 'Guía de estudio':
      return 'Indica qué debe repasar el estudiante, cuántas actividades deseas y el nivel de dificultad.';
    case 'Lista de cotejo':
      return 'Indica el desempeño o producto que observarás y los aspectos que quieres comprobar.';
    default:
      return 'Describe libremente lo que necesitas.';
  }
}

void _applyResourceTemplate(Map<String, dynamic> content, String type) {
  final originalSections = content['sections'];
  final source = originalSections is List
      ? originalSections.map((e) => e.toString()).join('\n')
      : '';

  content['source_status'] ??= 'Borrador estructurado con los datos proporcionados.';
  content['purpose'] ??= '';
  content['contents'] ??= source;

  switch (type) {
    case 'Evaluación / examen':
      content['instructions_for_student'] = content['instructions_for_student'] ?? content['evaluation'] ?? '';
      content['items'] = content['items'] ?? source;
      content['answer_key'] = content['answer_key'] ?? '';
      content['evaluation_criteria'] = content['evaluation_criteria'] ?? '';
      break;
    case 'Rúbrica':
      content['purpose'] = content['purpose'] ?? '';
      content['criteria'] = content['criteria'] ?? source;
      content['levels'] = content['levels'] ?? '';
      content['evidence'] = content['evidence'] ?? '';
      content['score'] = content['score'] ?? '';
      break;
    case 'Guía de estudio':
      content['purpose'] = content['purpose'] ?? '';
      content['explanation'] = content['explanation'] ?? content['contents'] ?? '';
      content['activities'] = content['activities'] ?? source;
      content['practice'] = content['practice'] ?? '';
      content['review'] = content['review'] ?? '';
      break;
    case 'Lista de cotejo':
      content['indicators'] = content['indicators'] ?? source;
      content['yes_no'] = content['yes_no'] ?? 'Sí / No';
      content['observations'] = content['observations'] ?? '';
      break;
  }
}

class DocumentsPage extends StatefulWidget {
  const DocumentsPage({super.key});

  @override
  State<DocumentsPage> createState() => _DocumentsPageState();
}

class _DocumentsPageState extends State<DocumentsPage> {
  bool loading = true;
  List<Map<String, dynamic>> docs = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;
      final data = await supabase.from('documents').select().eq('owner_id', user.id).order('created_at', ascending: false);
      if (mounted) setState(() => docs = List<Map<String, dynamic>>.from(data));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudieron cargar los documentos: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis documentos')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : docs.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('Aquí aparecerán tus documentos generados, cuando esté activo el módulo de generación.', textAlign: TextAlign.center),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(18),
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final d = docs[i];
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.description),
                        title: Text('${d['title'] ?? 'Documento'}'),
                        subtitle: Text('${d['document_type'] ?? ''}'),
                      ),
                    );
                  },
                ),
    );
  }
}


class PlansMenuPage extends StatelessWidget {
  const PlansMenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    const types = [
      ['Plan de clase', 'Una sesión con inicio, desarrollo y cierre.', Icons.class_outlined],
      ['Plan semanal', 'Distribución de contenidos para la semana.', Icons.view_week_outlined],
      ['Plan mensual', 'Vista general de contenidos del mes.', Icons.calendar_month_outlined],
      ['Plan remedial', 'Refuerzo para estudiantes que lo necesitan.', Icons.healing_outlined],
      ['Plan de recuperación', 'Actividades para recuperar aprendizajes.', Icons.replay_outlined],
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Planes')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('¿Qué plan quieres preparar?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          for (final t in types)
            Card(
              child: ListTile(
                leading: Icon(t[2] as IconData),
                title: Text(t[0] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(t[1] as String),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => CreatePlanPage(planType: t[0] as String)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
