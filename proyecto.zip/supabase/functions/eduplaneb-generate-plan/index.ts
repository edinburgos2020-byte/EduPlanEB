import "jsr:@supabase/functions-js/edge-runtime.d.ts";

type Json = Record<string, unknown>;
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const json = (body: Json, status = 200) => new Response(JSON.stringify(body), { status, headers: {...cors, "Content-Type":"application/json"} });

function fallback(body: Json): Json {
  const type = String(body.plan_type ?? "Plan de clase");
  const grade = String(body.grade ?? "");
  const subject = String(body.subject ?? "");
  const source = String(body.source_text ?? body.extracted_text ?? "").trim();
  const automatic = body.mode === "automatic";
  const schedule = Array.isArray(body.schedule) ? body.schedule : [];
  const distribution = String(body.distribution ?? "");
  return {
    title: String(body.lesson ?? "").trim() ? `${type}: ${body.lesson}` : type,
    grade, subject, pages: String(body.pages ?? ""), lesson: String(body.lesson ?? ""),
    book_title: String(body.book_title ?? ""), instructions: String(body.instructions ?? ""),
    resource_type: type, mode: automatic ? "automatic" : "manual",
    source_text_preview: source.substring(0, 3000),
    schedule_used: automatic ? schedule : [],
    distribution: automatic ? distribution : "",
    sections: ["Propósito de aprendizaje","Saberes y contenidos","Actividades de inicio","Actividades de desarrollo","Actividades de cierre","Evaluación","Recursos"],
    source_status: source ? "Texto fuente recibido." : "Sin texto fuente; revisar antes de imprimir."
  };
}

function schemaFor(type: string): string {
  const keys: Record<string, string> = {
    "Evaluación / examen": "instructions_for_student, items, evaluation_criteria, answer_key",
    "Rúbrica": "purpose, criteria, levels, evidence, score",
    "Guía de estudio": "purpose, explanation, activities, practice, review",
    "Lista de cotejo": "indicators, yes_no, observations",
  };
  const list = keys[type] ?? "purpose, contents, start, development, closing, evaluation, resources";
  return `El objeto JSON debe incluir exactamente estas claves de texto: title, ${list}.`;
}

function clean(value: string) {
  return value.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ok:false,error:"Método no permitido."},405);
  try {
    const body = await req.json() as Json;
    const source = String(body.source_text ?? body.extracted_text ?? "").trim();
    const apiKey = Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) return json({ok:true,mode:"fallback",content:fallback(body),warning:"Configura OPENAI_API_KEY en los secretos de Supabase para activar la generación real con IA."});

    const automatic = body.mode === "automatic";
    const schedule = Array.isArray(body.schedule) ? JSON.stringify(body.schedule) : "";
    const prompt = `Eres un asistente pedagógico para docentes. Genera un documento educativo listo para revisar y editar. Tipo: ${body.plan_type ?? "Plan de clase"}. Grado: ${body.grade ?? ""}. Asignatura: ${body.subject ?? ""}. Páginas: ${body.pages ?? ""}. Tema/lección: ${body.lesson ?? ""}. Instrucciones del docente: ${body.instructions ?? ""}. Modo: ${automatic ? "AUTOMÁTICO: distribuye el contenido en las clases disponibles y explica brevemente qué se trabajará en cada una." : "MANUAL: respeta las instrucciones y no redistribuyas por tu cuenta."}. Horario disponible: ${schedule}. Distribución indicada por el docente: ${body.distribution ?? ""}. Texto fuente del libro/material: ${source || "No se proporcionó texto fuente."}. Basa el documento primero en el texto fuente. No inventes contenidos que contradigan la fuente. Si falta información, indícalo. Adapta el nivel al grado y asignatura. ${schemaFor(String(body.plan_type ?? ""))} Todos los valores deben ser texto simple (string), sin objetos ni arreglos anidados; usa saltos de línea para listas. Devuelve SOLO un objeto JSON válido.`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${apiKey}`},
      body:JSON.stringify({
        model:Deno.env.get("OPENAI_MODEL") ?? "gpt-4.1-mini",
        temperature:0.3,
        response_format:{type:"json_object"},
        messages:[
          {role:"system",content:"Escribe en español claro y natural. Prioriza utilidad práctica para el docente."},
          {role:"user",content:prompt}
        ]
      })
    });
    if (!response.ok) {
      console.error("OpenAI error", await response.text());
      return json({ok:true,mode:"fallback",content:fallback(body),warning:"La IA no pudo responder en este momento."});
    }
    const result = await response.json();
    const raw = result?.choices?.[0]?.message?.content;
    if (!raw) return json({ok:true,mode:"fallback",content:fallback(body)});
    let content: Json;
    try { content = JSON.parse(clean(String(raw))); }
    catch { return json({ok:true,mode:"fallback",content:fallback(body),warning:"La respuesta de IA no tuvo un formato válido."}); }
    content.grade ??= body.grade ?? "";
    content.subject ??= body.subject ?? "";
    content.pages ??= body.pages ?? "";
    content.lesson ??= body.lesson ?? "";
    content.resource_type ??= body.plan_type ?? "Plan de clase";
    content.mode = automatic ? "automatic" : "manual";
    content.source_status = source ? "Generado a partir del texto fuente proporcionado." : "Generado sin texto fuente; revisar antes de imprimir.";
    return json({ok:true,mode:"ai",content});
  } catch (error) {
    console.error(error);
    return json({ok:false,error:error instanceof Error ? error.message : "Error interno."},500);
  }
});
