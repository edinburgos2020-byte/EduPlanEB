#!/usr/bin/env bash
# Ajusta el AndroidManifest generado por "flutter create" para que la APK release
# tenga acceso a internet (Supabase) y el nombre correcto en el celular.
set -euo pipefail
M="android/app/src/main/AndroidManifest.xml"
[ -f "$M" ] || { echo "No existe $M (ejecuta antes: flutter create --platforms=android --org com.eduplaneb .)"; exit 1; }
if ! grep -q 'android.permission.INTERNET' "$M"; then
  sed -i '0,/<manifest[^>]*>/s//&\n    <uses-permission android:name="android.permission.INTERNET"\/>/' "$M"
fi
sed -i 's/android:label="[^"]*"/android:label="EduPlanEB"/' "$M"
echo "Manifest listo:"; grep -n 'INTERNET\|android:label' "$M"
